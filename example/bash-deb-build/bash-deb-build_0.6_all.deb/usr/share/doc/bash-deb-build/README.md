bash-deb-build.  
0.6

# Bash DEB build.

Bash-script for build deb package:
1. build:
 *  fakeroot bash-deb-build
2. unpack:
 *  bash-deb-unpack package.deb
3. depends:
 *  bash-deb-depends-test you-etf-or-lib

## Depends

dpkg, grep, tar, gzip, bzip2, lzma, coreutils, binutils

---  
2021  
zvezdochiot  
https://github.com/BASH-Auto-Tools/bash-deb-build
